package se.vgr.javg.util.webcomponent.support.taglib;

import javax.faces.context.FacesContext;

public class WebComponentTagFunctions {
	
	private WebComponentTagFunctions() {
	}
	
	/** 
	 * @return the context path for the webapp
	 */
	public static final String ctxPath() {
		String ctxPath = FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath();
		return ctxPath + "/";
	}

	/** 
	 * @return the encoded name (for uniqueness in a page)
	 */
	public static final String encNs(String name) {
		return FacesContext.getCurrentInstance().getExternalContext().encodeNamespace(name);
	}	
}
