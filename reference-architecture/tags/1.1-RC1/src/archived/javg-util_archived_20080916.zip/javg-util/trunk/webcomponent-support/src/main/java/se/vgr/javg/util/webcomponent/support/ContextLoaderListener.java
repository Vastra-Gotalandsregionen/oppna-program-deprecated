package se.vgr.javg.util.webcomponent.support;

/**
 * Specialization of the Spring ContextLoaderListener.
 * Uses the ContextLoader to wraps the ApplicationContext
 * maintained by SpringContextHelper.
 * 
 * @see org.springframework.web.context.ContextLoaderListener
 */
public class ContextLoaderListener extends org.springframework.web.context.ContextLoaderListener {
    
    protected org.springframework.web.context.ContextLoader createContextLoader() {
        return new se.vgr.javg.util.webcomponent.support.ContextLoader();
    }

}
