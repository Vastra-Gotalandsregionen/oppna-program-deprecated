package se.vgr.javg.util.portlet.support;

import java.io.IOException;
import java.util.Enumeration;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.UnavailableException;
import org.apache.myfaces.portlet.MyFacesGenericPortlet;

public class JSFPortlet extends MyFacesGenericPortlet {
		
	public void init() throws UnavailableException, PortletException {		
		super.init();
		
		// WORKAROUND for MyFaces 1.1.4 possible NullPointerException in
		// Portlet environment as detailed in:
		// http://wiki.apache.org/myfaces/PortletSerialFactoryWorkaround
		getPortletContext().setAttribute("org.apache.myfaces.SERIAL_FACTORY",
				new org.apache.myfaces.shared_impl.util.serial.DefaultSerialFactory()); 
	}
	
	
    public void processAction(ActionRequest request, ActionResponse response)
    	throws PortletException, IOException {
    	
//    	System.out.println("*** DEBUG START processAction ****");
//    	debug(request);    	
//		System.out.println("*** DEBUG END processAction ****");
    	
    	super.processAction(request, response);
    }

    
    protected void facesRender(RenderRequest request, RenderResponse response)
    	throws PortletException, java.io.IOException {

//    	System.out.println("*** DEBUG START facesRender ****");
//    	debug(request);    	
//		System.out.println("*** DEBUG END facesRender ****");

		super.facesRender(request, response);
    }

    
    private void debug(PortletRequest request) {
		Enumeration names =  request.getParameterNames();
		while (names.hasMoreElements()) {
			String name = (String) names.nextElement();
			Object values = request.getParameterMap().get(name);
			if (values == null) {
				System.out.println("param: " + name + "   values: NULL");
			}
			else {
				String[] varr = (String[]) values;
				for (int i = 0; i < varr.length; i++) {
					System.out.println("param: " + name + "   value[" + i + "]:" + varr[i]);	
				}
			}				
		}
    }    
}
