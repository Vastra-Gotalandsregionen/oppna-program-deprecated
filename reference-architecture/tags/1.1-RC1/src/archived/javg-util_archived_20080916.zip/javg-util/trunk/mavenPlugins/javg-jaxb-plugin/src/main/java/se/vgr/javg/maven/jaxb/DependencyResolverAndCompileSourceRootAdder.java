package se.vgr.javg.maven.jaxb;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Pattern;
import org.apache.maven.artifact.Artifact;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.project.MavenProject;

/**
 * Adds the generated-sources dir to the compile path and generates an
 * Ant-script for unpacking any dependencies to the target-dir.
 * <p>A regexp-filter can be specified with <artifactfilter>, syntax as in
 * described in <code>java.util.regex.Pattern</code>. 
 * <p>Appends to a template Ant-script. 
 * 
 * @goal resolve_deps
 * @phase generate-sources
 * @requiresDependencyResolution compile
 * 
 * @author Hakan Dahl, Callista Enterprise
 */
public class DependencyResolverAndCompileSourceRootAdder extends AbstractMojo {
	
	/**
	 * The output file to write the Ant-style fileset to.
	 */
	private static String ANT_OUTPUT_FILENAME = "ant_unzip_dependencies.xml";
	/**
	 * The Ant-template file to read from the classpath.
	 */
	private static String ANT_TEMPLATE_FILENAME = "ant_unzip_dependencies.template.xml";
	/**
	 * Insert the Ant-style fileset after this line in the template.
	 */
	private static String ANT_TEMPLATE_INSERT_POINT = "@INSERT_FILESET_AFTER_THIS_LINE@";
	
	
    /**
     * The list of dependency artifacts resolved for this project.
     * @parameter default-value="${project.artifacts}"
     * @required
     * @readonly
     */
    private Set dependencies;
        
    /**
     * @parameter expression="${localRepository}"
     */
    private org.apache.maven.artifact.repository.ArtifactRepository localRepository;
    /**
     * A filter to apply to the dependency artifactId for inclusion of the
     * artifact.
     * <p>Example: .*jar would include all dependency jar-files. 
     * 
     * @see java.util.regex.Pattern for regexp pattern  
     *  
     * @parameter 
     */    
    private String artifactIdFilter;
    /**
     * @parameter expression="${project.build.directory}"
     * @required
     * @readonly 
     */
    private String targetDirPath;
    /**
     * @parameter expression="${basedir}/src/main/schema"
     * @required
     * @readonly
     */
    private String schemaDirPath;
    /**
     * @parameter expression="${project.build.directory}/generated-sources/jaxb"
     * @required
     * @readonly 
     */
    private String jaxbSourceDirPath;
    /**
    * @parameter default-value="${project}"
    * @required
    * @readonly
    */
    private MavenProject project;
    
    
    private String localRepositoryPath;
    private Pattern artifactPattern;
    private ArrayList fileList;
    

	public void execute() throws MojoExecutionException, MojoFailureException {
		// only execute if schema dir exists and contains schema
		if (!schemaDirExistsAndContainsSchema()) {
			return;
		}
		addJaxbSourceRootDirToMaven();
		
		initAfterInjection();
		
		for (Iterator iter = dependencies.iterator(); iter.hasNext();) {
			Artifact artifact = (Artifact) iter.next();
			if (isPatternMatch(artifact.getArtifactId())) {
				String pathWithinRepo = stripLocalRepositoryPathPrefix(artifact.getFile().getPath());
				fileList.add(pathWithinRepo);
				getLog().info("Adding artifact: " + artifact.getFile().getName());
			}
		}
		
		getLog().info("Number of artifacts in fileset: " + fileList.size());
		
		if (fileList.size() > 0) {
			generateAntScriptFromTemplate();	
		}
	}
	
	private boolean schemaDirExistsAndContainsSchema() {
		File schemaDir = new File(schemaDirPath);
		if (schemaDir.exists() && schemaDir.isDirectory()) {
			final Pattern p = Pattern.compile(".*xsd");
			String[] list = schemaDir.list(new FilenameFilter(){
				public boolean accept(File dir, String name) {
					return p.matcher(name).matches();
				}
			});
			if (list.length > 0) {
				return true;
			}
		}
		return false;
	}
	
	private void addJaxbSourceRootDirToMaven() throws MojoExecutionException {
		File srcDir = new File(jaxbSourceDirPath);
		if (!srcDir.exists() && !srcDir.mkdirs()) {
			throw new MojoExecutionException("Could not create dir: " + srcDir);
		}
		project.addCompileSourceRoot(jaxbSourceDirPath);
	}
	
	private void initAfterInjection() {
		// default filter, match everything
		String filter = ".*";
		if (artifactIdFilter != null) {
			filter = artifactIdFilter;
			getLog().info("Using filter: " + artifactIdFilter);
		}
		localRepositoryPath = localRepository.getBasedir();
		artifactPattern = Pattern.compile(filter);
		fileList = new ArrayList();
	}
	
	boolean isPatternMatch(String artifactId) {
		return artifactPattern.matcher(artifactId).matches();
	}
	
	String stripLocalRepositoryPathPrefix(String fileName) {
		return fileName.substring(localRepositoryPath.length() + 1);
	}
	
	private void generateAntScriptFromTemplate() throws MojoExecutionException {
		try {
			// get the template from classpath
			InputStream ins = getClass().getClassLoader().getResourceAsStream(ANT_TEMPLATE_FILENAME);
			InputStreamReader isr = new InputStreamReader(ins);
			BufferedReader template = new BufferedReader(isr);

			// create target dir
			File targetDir = new File(targetDirPath);
			if (!targetDir.exists() && !targetDir.mkdirs()) {
				throw new MojoExecutionException("Could not create dir: " + targetDir);
			}
			
			FileWriter fw = new FileWriter(targetDir + File.separator + ANT_OUTPUT_FILENAME);
			BufferedWriter outfile = new BufferedWriter(fw); 
			String s;
			while ((s = template.readLine()) != null) {
				if (s.contains(ANT_TEMPLATE_INSERT_POINT)) {
					// insert fileset
					appendAntFileSet(outfile);
				}
				else {
					outfile.write(s);
					outfile.newLine();
				}
			}
			outfile.flush();
			outfile.close();
			
			template.close();
			isr.close();
			ins.close();			
		}
		catch (IOException e) {
			throw new MojoExecutionException("Error generating ant-script", e);
		}
	}
	
	private void appendAntFileSet(BufferedWriter outfile) throws IOException {
		if (artifactIdFilter == null) {
			outfile.write("<!-- No artifact filter configured. -->");
			outfile.newLine();
		}
		else {
			outfile.write("<!-- Using configured artifact filter: ");
			outfile.write(artifactIdFilter);
			outfile.write(" -->");
			outfile.newLine();
		}
		
		outfile.write("<fileset dir=\"");
		outfile.write(localRepositoryPath);
		outfile.write("\">");
		outfile.newLine();
		
		for (Iterator iter = fileList.iterator(); iter.hasNext();) {
			String file = (String) iter.next();
			outfile.write("  <include name=\"");
			outfile.write(file);
			outfile.write("\"/>");
			outfile.newLine();
		}
					
		outfile.write("</fileset>");
		outfile.newLine();
	}
	
}
