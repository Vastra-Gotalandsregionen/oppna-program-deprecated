User settings
==============================
Put settings.xml into directory $USER_HOME/.m2.

For example, on Windows XP that would be in:

C:\Documents and Settings\<username>\.m2



Continuous Integration settings
==============================
Put settings.xml into directory $M2_HOME/conf on the integration server host.
That way, is doesn't matter who is running the build, the settings will be the
same anyway.
Difference to user settings: DO NOT DISTRIBUTE STABLE RELEASES since that is
expected to be a manual task (effectively means that stable releases should be
put in a place where they are not exposed to users).
