package se.vgr.javg.examples.portletexample.presentation;

import java.util.List;

import se.vgr.core.schema.addressentry.AddressEntryType;
import se.vgr.javg.examples.portletexample.schema.AddressEntrySdoHelper;
import se.vgr.javg.examples.portletexample.types.AddressEntry;


/**
 * Fetch list of all addresses. 
 */
public class AddressListFlowSupportBean {
	public static final String VIEW_NAME = "addresslist";
	private se.vgr.core.wsdl.addressservices.AddressService addressIntService;

	public se.vgr.core.wsdl.addressservices.AddressService getAddressIntService() {
		return addressIntService;
	}

	public void setAddressIntService(
			se.vgr.core.wsdl.addressservices.AddressService addressIntService) {
		this.addressIntService = addressIntService;
	}
	
	/**
	 * Uses integration service to access service layer.
	 */
	public List<AddressEntry> getEntries() {
		se.vgr.core.wsdl.addressservices.AddressService service = getAddressIntService();
		return AddressEntrySdoHelper.fromAddressEntryListType(service.getAddressEntries("dummyparam"));
	}
}
