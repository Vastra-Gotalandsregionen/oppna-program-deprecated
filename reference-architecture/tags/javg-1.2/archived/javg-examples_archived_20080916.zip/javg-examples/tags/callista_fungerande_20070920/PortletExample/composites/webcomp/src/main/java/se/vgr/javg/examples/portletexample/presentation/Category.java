package se.vgr.javg.examples.portletexample.presentation;

import java.io.Serializable;

/**
 * Simple holder class to support form based entry.
 * @author johan
 *
 */
public class Category implements Serializable {
	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
