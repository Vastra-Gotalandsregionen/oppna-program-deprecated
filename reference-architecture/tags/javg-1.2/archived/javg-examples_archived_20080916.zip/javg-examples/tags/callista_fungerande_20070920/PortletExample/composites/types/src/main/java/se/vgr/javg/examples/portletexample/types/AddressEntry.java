package se.vgr.javg.examples.portletexample.types;

import java.io.Serializable;

/**
 * A Data Transfer Object (DTO).
 */
public class AddressEntry implements Serializable {
	private long entryId; // typically a primary key
	private String name;
	private String street;
	private String city;
	private String category;
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public long getEntryId() {
		return entryId;
	}
	public void setEntryId(long entryId) {
		this.entryId = entryId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
}
