package se.vgr.javg.examples.portletexample.svc;

import java.util.List;

import se.vgr.javg.examples.portletexample.types.AddressEntry;

public interface AddressService {

	public abstract AddressEntry[] getAddressEntries();

	public abstract AddressEntry getAddressEntry(long primaryKey);

	public abstract void saveAddressEntry(AddressEntry entry);

	public abstract List<String> getCategories();

	public abstract void saveCategory(String category);

}