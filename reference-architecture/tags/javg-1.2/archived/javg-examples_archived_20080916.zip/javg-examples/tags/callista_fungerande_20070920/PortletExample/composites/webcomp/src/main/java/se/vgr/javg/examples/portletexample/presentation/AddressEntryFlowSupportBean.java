package se.vgr.javg.examples.portletexample.presentation;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.model.SelectItem;

import se.vgr.core.schema.addressentry.AddressEntryType;
import se.vgr.core.wsdl.addressservices.AddressService;
import se.vgr.javg.examples.portletexample.schema.AddressEntrySdoHelper;
import se.vgr.javg.examples.portletexample.types.AddressEntry;

/**
 * Fetch details and allow for updating or creating a new entry.
 */
public class AddressEntryFlowSupportBean {

	private AddressService addressService;

	public AddressService getAddressService() {
		return addressService;
	}

	public void setAddressService(AddressService addressService) {
		this.addressService = addressService;
	}

	public List<SelectItem> getCategories() {
		// initialize select-list
		List<SelectItem> categories = new ArrayList<SelectItem>();
		for (String category : getAddressService().getCategories("dummyparam").getCategory()) {
			categories.add(new SelectItem(category, category, ""));
		}
		return categories;
	}

	public void saveEntry(AddressEntry entry) {
		getAddressService().saveAddressEntry(AddressEntrySdoHelper.toAddressEntryType(entry));
	}

	public AddressEntry getNewOrExistingAddressEntry(Object entryId) {
		return entryId == null ? getNewAddressEntry() : AddressEntrySdoHelper.fromAddressEntryType(addressService.getAddressEntry((Long)entryId));
	}

	public AddressEntry getNewAddressEntry() {
		AddressEntry newEntry = new AddressEntry();
		newEntry.setCategory(getAddressService().getCategories("dummyparam").getCategory().get(0));
		return newEntry;
	}

}
