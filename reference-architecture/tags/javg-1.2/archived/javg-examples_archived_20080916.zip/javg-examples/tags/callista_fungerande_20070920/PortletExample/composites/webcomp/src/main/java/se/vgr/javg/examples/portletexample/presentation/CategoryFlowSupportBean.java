package se.vgr.javg.examples.portletexample.presentation;

import java.io.Serializable;
import se.vgr.core.wsdl.addressservices.AddressService;

public class CategoryFlowSupportBean {
	
	private AddressService addressService;

	public AddressService getAddressService() {
		return addressService;
	}

	public void setAddressService(AddressService addressService) {
		this.addressService = addressService;
	}
	
	public void saveNewCategory(Category newCategory) {	
		getAddressService().saveCategory(newCategory.getValue());
	}
		
}
