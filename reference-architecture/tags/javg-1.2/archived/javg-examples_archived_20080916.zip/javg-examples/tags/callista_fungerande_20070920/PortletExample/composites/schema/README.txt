Vi anv�nder WebService-infrastrukturen cxf fr�n Apache. De har inte fullt ut lyckats med att h�lla alla biblioteken i n�got publikt maven repo. D�rf�r beh�ver en av filerna manuellt installeras i ditt lokala repository (eller f�retagets interna centrala repo). F�ljande instruktioner hj�lper dig i m�l med detta eng�ngsmoment:

1. H�mta den bin�ra cxf distributionen, version 2.0.1 fr�n apache:
http://incubator.apache.org/cxf/download.html

2. Packa upp nedladdad zip-fil och �ppna ett kommandof�nster i katalogen lib. K�r d�r f�ljande kommando:

>mvn install:install-file -DgroupId=org.apache.cxf -DartifactId=cxf -Dversion=2.0.1-incubator -Dpackaging=jar -Dfile=cxf-2.0.1-incubator.jar
