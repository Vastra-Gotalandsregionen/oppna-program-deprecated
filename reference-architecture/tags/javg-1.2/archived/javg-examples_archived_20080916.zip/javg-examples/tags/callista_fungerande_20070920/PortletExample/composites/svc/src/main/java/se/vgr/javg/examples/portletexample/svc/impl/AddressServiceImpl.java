package se.vgr.javg.examples.portletexample.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import se.vgr.javg.examples.portletexample.svc.AddressService;
import se.vgr.javg.examples.portletexample.types.AddressEntry;

/**
 * A service that encapsulates an in-memory storage for testing and demo
 * purpose. 
 */
public class AddressServiceImpl implements AddressService {
	private static long primaryKeySequence = 0;
	private Map addressEntryMap;
	private List<String> categoryList;
	
	public AddressServiceImpl() {
		addressEntryMap = new HashMap();
		categoryList = new ArrayList<String>();
		populateWithDefaultData();
	}
	
	/* (non-Javadoc)
	 * @see se.vgr.javg.examples.portletexample.svc.AddressService#getAddressEntries()
	 */
	public AddressEntry[] getAddressEntries() {
		return (AddressEntry[]) addressEntryMap.values().toArray(new AddressEntry[addressEntryMap.size()]);
	}
		
	/* (non-Javadoc)
	 * @see se.vgr.javg.examples.portletexample.svc.AddressService#getAddressEntry(long)
	 */
	public AddressEntry getAddressEntry(long primaryKey) {
		return (AddressEntry) addressEntryMap.get(new Long(primaryKey));
	}

	/* (non-Javadoc)
	 * @see se.vgr.javg.examples.portletexample.svc.AddressService#saveAddressEntry(se.vgr.javg.examples.portletexample.types.AddressEntry)
	 */
	public void saveAddressEntry(AddressEntry entry) {
		// provide a primary key if new entry
		if (entry.getEntryId() == 0) {
			entry.setEntryId(getNextPrimaryKey());
		}
		addressEntryMap.put(new Long(entry.getEntryId()), entry);
	}

	/* (non-Javadoc)
	 * @see se.vgr.javg.examples.portletexample.svc.AddressService#getCategories()
	 */
	public List<String> getCategories() {
		return categoryList;
	}	
	
	/* (non-Javadoc)
	 * @see se.vgr.javg.examples.portletexample.svc.AddressService#saveCategory(java.lang.String)
	 */
	public void saveCategory(String category) {
		categoryList.add(category);
	}
	
	private long getNextPrimaryKey() {
		return ++primaryKeySequence;
	}
	
	private void populateWithDefaultData() {
		String defaultCategory = "Private";
		
		// categories
		categoryList.add(defaultCategory);

		
		addDefaultEntry("Lina Johansson", "Linas v�g", "G�teborg", defaultCategory);
		addDefaultEntry("Erik Eriksson", "Eriksgatan", "Alings�s", defaultCategory);
		addDefaultEntry("Anders Andersson", "Anders v�g", "Kungsbacka", defaultCategory);		
	}
	
	private void addDefaultEntry(String name, String street, String city, String category) {
		AddressEntry ae = new AddressEntry();
		ae.setEntryId(getNextPrimaryKey());
		ae.setName(name);
		ae.setStreet(street);
		ae.setCity(city);
		ae.setCategory(category);
		addressEntryMap.put(new Long(ae.getEntryId()), ae);
	}
}
