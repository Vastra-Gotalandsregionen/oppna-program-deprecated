package se.vgr.javg.examples.portletexample.presentation;

import java.util.ArrayList;
import java.util.List;
import se.vgr.javg.examples.portletexample.svc.AddressService;
import se.vgr.javg.examples.portletexample.types.AddressEntry;


/**
 * Fetch list of all addresses. 
 */
public class AddressListFlowSupportBean {
	public static final String VIEW_NAME = "addresslist";
	private AddressService addressService;

	public AddressService getAddressService() {
		return addressService;
	}

	public void setAddressService(AddressService addressService) {
		this.addressService = addressService;
	}
	
	/**
	 * Uses integration service to access service layer.
	 */
	public List<AddressEntry> getEntries() {
		AddressEntry[] entries = getAddressService().getAddressEntries();
		List<AddressEntry> result = new ArrayList<AddressEntry>();
		for (AddressEntry entry : entries) {
			result.add(entry);
		}
		return result;
	}
}
